# script.skin.helper.service
a helper service for Kodi skins

________________________________________________________________________________________________________


All documentation for this addon can be found in the online wiki:

https://github.com/marcelveldt/script.skin.helper.service/wiki


